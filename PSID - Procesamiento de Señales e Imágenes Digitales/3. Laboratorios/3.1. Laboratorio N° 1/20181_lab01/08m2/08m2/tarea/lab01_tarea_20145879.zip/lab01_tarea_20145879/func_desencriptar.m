%% PSID Tarea Extra
% Autor: Pablo D�az Vergara
% C�digo: 20145879
% Fecha de entrega: 13/04/18
% Ciclo: 2018-1
%% 2.c
function [decoded_str]=func_desencriptar(coded_str,s)
    % 2.c.i
    ref_v=double(coded_str); % codificacion en ascii
    
    % 2.c.ii
    lower=(97:1:122); % rango asccii letras minusculas
    upper=(65:1:90); % rango asccii letras mayusculas
    num=(48:1:57); % rango asccii numeros
    ref_v=[num(1,:) upper(1,:) lower(1,:) ]; % valores posibles del vector
    ref_size=length(ref_v); % Se verifica el n�mero de elementos del vector
    
    % 2.c.iii
    rng(s);
    randpos_v=randperm(ref_size); % reordenamiento usado en la etapa de encriptacion
    randref_v=ref_v(randpos_v); % secuencia ASCII con mismo reordenamiento que la etapa de encriptaci�n
    
    % 2.c.iv
    decoded_str=zeros(1,length(coded_str));
    % Reordenamos seg�n el nuevo indice
    for j=1:length(coded_str) % para cada simbolo
       for i=1:ref_size
           % primero encontramos la posicion en el codigo ascii
           if coded_str(j)==randref_v(i)
                decoded_str(j)=ref_v(i);
           end          
        end
    end
    decoded_str=char(decoded_str);
end