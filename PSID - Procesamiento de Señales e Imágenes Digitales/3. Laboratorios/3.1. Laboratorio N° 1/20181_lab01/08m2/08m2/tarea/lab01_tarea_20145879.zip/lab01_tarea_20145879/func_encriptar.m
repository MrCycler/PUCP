%% PSID Tarea Extra
% Autor: Pablo D�az Vergara
% C�digo: 20145879
% Fecha de entrega: 13/04/18
% Ciclo: 2018-1
%% 2.b

function [coded_str,s]=func_encriptar(input_str)
% 2.b.i
input_double=double(input_str); % convertimos la entrada en una variable de tipo double
%whos input_double; % vemos el tipo de variable
length(input_double); %vemos el tama�o del vector
columnas=length(input_double);

% 2.b.ii
mask_lower=input_double>=97&input_double<=122;
mask_upper=input_double>=65&input_double<=90;
mask_num=input_double>=48&input_double<=57;

suma_mask=mask_lower+mask_upper+mask_num;
    for index=1:columnas % Bucle para revisar el estado l�gico de cada elemento del vector
        if (suma_mask(index)==1)
        else
        error( 'Error: Argumento de entrada contiene caracteres que no son letras o numeros enteros positivos incluyendo 0.');
        end
    end

% 2.b.iii
lower=(97:1:122); % rango asccii letras minusculas
upper=(65:1:90); % rango asccii letras mayusculas
num=(48:1:57); % rango asccii numeros
ref_v=[num(1,:) upper(1,:) lower(1,:) ]; % valores posibles del vector
ref_size=length(ref_v); % Calcula la longitud del vector

% 2.b.iv
s=rng; % Semilla
randpos_v=randperm(ref_size);% Ordenamiento pseudo- aleatorio
randref_v=ref_v(randpos_v); % Posibles codigos ASCII reordenados

% 2.b.v
coded_str=zeros(1,ref_size); % Creamos un vector del mismo tama�o
% Reordenamos seg�n el nuevo indice
    for j=1:length(input_str) % para cada simbolo
       for i=1:ref_size
           % primero encontramos la posicion en el codigo ascii
           if input_str(j)==ref_v(i)
               posicion=i;
                coded_str(j)=randref_v(posicion);
           end          
        end
    end
coded_str=char(coded_str); %Mensaje encriptado
end %FIN FUNCION ENCRIPTAR