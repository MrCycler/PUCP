%% PSID Tarea Extra
% Autor: Pablo D�az Vergara
% C�digo: 20145879
% Fecha de entrega: 13/04/18
% Ciclo: 2018-1
%% Limpiar pantalla, borrar variables, cerrar gr�ficos

clear all;
close all;
clc;

%% 1.1. Variables escalares
% i
a=10;
% ii
b=pi^(1.5);
% iii
c=exp(j*(pi+1/4));
% iv
d=atan(0.45);

% Mostramos resultados
disp(a);
disp(b);
disp(c);
disp(d);

%% 1.2. Variables vectoriales
% i
aVec=[2*j 5 exp(j*pi) 1/3];
% ii
bVec=[1*10^3; 0.1;cos(pi/2-1/4);50];
% iii
cVec=[10:-0.25:-10];
% iv
dVec=[2.^(3:-0.5:-3)];
% v
eVec=['Jacobiano'];

% Mostramos resultados
disp(aVec);
disp(bVec);
disp(cVec);
disp(dVec);
disp(eVec);

%% 1.3. Variables Matriciales
% i
aMat=zeros(15);
aMat(8,:)=(-7:1:7);
aMat(:,7)=(-14:2:14);
% ii
bMat=diag((13:-1:0),1)+diag((0:1:13),-1)+ones(15);
% iii
cMat=reshape(cos(2*pi*(0:1:224)/225),[15,15]);
% iv
dMat=hankel(2.^(1:2:9),2.^(9:-2:1));
% v
eMat=randi([20 30],6,10);
% vi
fMat=reshape((1:16),[4,4]);
fMat(mod(fMat,7)==0)=Inf;
fMat(mod(fMat,3)==0)=NaN;
% Mostramos resultados
disp(aMat);
disp(bMat);
disp(cMat);
disp(dMat);
disp(eMat);
disp(fMat);

%% 1.4. Ecuaciones con escalares

% i
x=log(a/b)/log(1/3);
% ii
y=(factorial(ceil(b)))/sqrt(-imag(c));
% iii
z=(conj(exp(c)))*j*a/sqrt(b+j*c);

% Mostramos resultados
disp(x);
disp(y);
disp(z);

%% 1.5. Ecuaciones con vectores

% i
xVec=1/(2*pi)*exp(((aVec-a).^2)/transpose(bVec));
% ii
yVec=(aVec.*bVec)./sqrt(transpose(aVec)+bVec);
% iii.
zVec=sin(dVec+2);

% Mostramos resultados
disp(xVec);
disp(yVec);
disp(zVec);

%% 1.6 Ecuaciones con matrices

% a
xMat= transpose(aVec).*aVec;
% b
yMat=aMat*cMat+aMat.*cMat;
% c
zMat=exp((tan(dMat)*ones(5,15))*transpose(cMat));
% Mostramos resultados
disp(xMat);
disp(yMat);
disp(zMat);

%% 2 Uso de subrutinas
%% 2.a
input_str='ABCDwxyz0123';
whos input_str;
% longitud=12
% tipo de var= char
%% 2.d
% Caso 1
demo1='Pseudoinversa';
[code1,s1]=func_encriptar(demo1);
decrip_demo1=func_desencriptar(code1,s1);
disp(['Secuencia de entrada :', demo1]);
disp(['Secuencia encripatada :', code1]);
disp(['Secuencia desencriptada :', decrip_demo1]);
disp('------------------------------------------');
% Caso 2
demo2='e=mc2trooper';
[code2,s2]=func_encriptar(demo2);
decrip_demo2=func_desencriptar(code2,s2);
disp(['Secuencia de entrada :', demo2]);
disp(['Secuencia encripatada :', code2]);
disp(['Secuencia de entrada :', decrip_demo2]);
disp('------------------------------------------');
%Caso 3
demo3='Pucp2018';
[code3,s3]=func_encriptar(demo3);
decrip_demo3=func_desencriptar(code3,s3);
disp(['Secuencia de entrada :', demo3]);
disp(['Secuencia encripatada :', code3]);
disp(['Secuencia de entrada :', decrip_demo3]);

%% 3 Funciones Comunes e indexado
%% 3.a

i01_mat=imread('i03.jpg');
whos i01_mat;
%% 3.b
figure
subplot(1,3,1)

imshow(i01_mat);
title('io3.jpg');
%plot(i01_mat);
%subplot(i01_mat);
%% 3.c

r=randi([0 15], 1,1); % usar rand()

bit4=bitget(r,4,'uint8'); % extraigo el bit 4
bit7=bitget(r,1,'uint8'); % extraigo el bit 7
%% 3.d

bit4=bitget(i01_mat,5,'uint8');
bit7=bitget(i01_mat,8,'uint8');
subplot(1,3,2)
imshow(bit4*255); % imprimimos los bits4 de toda la ima
title('bit4');
subplot(1,3,3)
imshow(bit7*255); % imprimimos los bits7 de toda la imagen
title('bit7')
            %De ambos bits, cual contiene
             %mas informacion acerca de la
             %estructura de la imagen? Justificar
             %claramente su respuesta e incluirla              
             %en sus comentarios.
%% 3.e.i
load i03_vars.mat; % cargar variables

I_lsb=[2^0.*X0+2^1.*X1+2^2.*X2+2^3.*X3];
%% 3.e.ii

X_cell{1}=X4;
X_cell{2}=X5;
X_cell{3}=X6;
X_cell{4}=X7;
%% 3.e.iii
  
idx=1:4; %indices
C_mat=perms(idx); % posibles permutaciones
%% 3.e.iv
% Encontrar el orden correcto
% Algoritmo 1
P=24;   % n�mero de permutaciones

for i=0:P-1
   I=I_lsb;   % Inicializar acumulador
   for j=0:3
       w=2^(j+4); % Peso del bit actual
       a=C_mat(i+1,j+1); %indice actual de la combinaci�n
       I=I+w.*X_cell{a};
   end
   a=single(I(:,:,1)); % imagen vectorizada
   b=single(I_lsb(:,:,1)); %imagen original vectorizada
  error(i+1)=norm(a)-norm(b); % Calc. la dist. euclidiana
end

[i_true,columna_i]=min(error);  %Extraigo el valor y el index de
                                % la iteracion correcta

bit4_real=X_cell{C_mat(columna_i,1)};   %Guardo los valores
bit5_real=X_cell{C_mat(columna_i,2)};
bit6_real=X_cell{C_mat(columna_i,3)};
bit7_real=X_cell{C_mat(columna_i,4)};

% Junto los vectores
I_reconstruida=I_lsb+2.^4*bit4_real+2.^5*bit5_real+2.^6*bit6_real+2.^7*bit7_real;

%Ploteo los resultados
figure
subplot(1,2,1)
imshow(I_reconstruida);
title('Imagen reconstruida');

subplot(1,2,2)
imshow(i01_mat);
title('Imagen original');


%% Problema 4
%% 4.a

x_ideal=0:1/100:10; % Creamos el vector
fx_ideal=0.25.*x_ideal+3; % Creamos el vector f(x)
figure
subplot(1,3,1)
plot(x_ideal,fx_ideal);
xlabel('x');
ylabel('f(x)');
title('Curfa f(x)');
axis tight;
grid on;
grid minor;

%% 4.b

x_obs=0:1/20:10; % Creamos el vector

fx_obs=zeros(size(x_obs));
v_normal=zeros(size(x_obs));
mu=0;

sigma=0.1;
for n=1:201
v_normal(n)=mu+sigma.*randn();
end

fx_obs=v_normal+0.25.*x_obs+3;        % Creamos el vector con ruido

subplot(1,3,2)
plot(x_obs,fx_obs,'r o');
xlabel('x');
ylabel('b_f (x)');
title('Observaci�n b_f (x)');
axis tight;
grid on;
grid minor;


clearvars n sigma mu; 
%% 4.c
% A partir de x_obs crear X

X=ones(length(x_obs),2);
X(:,1)=x_obs(:);

b_v=reshape(fx_obs,[],1);

a_hat=(transpose(X)*X)\transpose(X)*b_v(:);
alpha_hat=a_hat(1);
beta_hat=a_hat(2);

% Ploteamos
subplot(1,3,3)
plot(x_obs,alpha_hat*x_obs+beta_hat,'g -');
xlabel('x');
ylabel('b_f (x)');
title('Observaci�n b_f (x)');
axis tight;
grid on;
grid minor;


%% 4.d

x_ideal=0:1/100:3;
gx_ideal=-4.*x_ideal.^2+12.*x_ideal+1;

%% 4.e
x_obs=0:1/20:3;

gx_obs=zeros(size(x_obs));
v_normal=zeros(size(x_obs));
mu=0;
sigma=0.1;
gx_ideal=-4.*gx_obs.^2+12.*gx_obs+1;

v_normal(1:end-1)=mu+sigma.*randn();

gx_obs=gx_ideal+v_normal;


clearvars  sigma mu;

%% 4.f

mu=0;
sigma=0.1;
x_obs=-9:1/100:1;
fx_obs=4.*(x_obs+2).^2+12.*(x_obs+2)+1;
a_search=-9:1/100:1;
a=zeros (size(a_search));
G_v=zeros(size(a_search));
tol=1;      % Tolerancia para condicion de parada
a_o=mu+sigma*randn();
c=10^(-4);



for i=1:length(a_search)
    if i==1
    G_v_o=0.5*sum(a_o-a_search(i))^2;
    grad=(a_o-a_search(i))*a_search(i)^2;
    a=a_o-c*grad;
    end
    if i>1
    G_v(i-1)=0.5*sum(a*x_obs(i)^2+12*x_obs(i)+1-a_search(i))^2;
    grad=(a*x_obs(i).^2+12*x_obs(i)+1-a_search(i))*a_search(i)^2;
    a=a_o-c*grad;
    end
  %  if abs(a(i)-a(i-1))<tol
  %  end
end


figure
subplot(1,3,1)
plot(x_obs,fx_obs.*100,'blue');
hold on;
xlabel('a');
plot(x_obs,G_v,'r o');
title('B�squeda de l�nea');
axis tight;
grid on;
grid minor;
axis([-10 1/100 -800 14000]);

clearvars a sigma mu;

%% 4.g

%% 4.h

%% 4.i


%% Problema 5
%% 5.a

tabla=readtable('q05.csv');    
raw_cell=table2array(tabla);

clearvars tabla;
%% 5.b

ret='Retirado';
x=strcmp(ret,raw_cell);
mascara=x(:,11);

for i=1:length(mascara)
    % Enmascaramos los indices v�lidos
    if (mascara(i)==0)
        mascara(i)=2;
    elseif (mascara(i)==1)
        mascara(i)=0;
    elseif (mascara(i)==2)
        mascara(i)=1;
    end
end
i=1;
% Eliminamos retirados
for j=1:length(mascara)
    
    if (mascara(j))==1
        valid_cell(i,1:11)=raw_cell(j,1:11);
        i=i+1;
    end
end
% En este momento ya tenemos los returados eliminados
clearvars i x ret j;

%% 5.c

% Almacenamos por horarios
h01='h01';
h02='h02';
llave_01=strcmp(h01,valid_cell(1:end,1));
llave_02=strcmp(h02,valid_cell(1:end,1));
% las llaves contienen un 1 si son del horario
m=1;
n=1;
for i=1:length(llave_01)
   if llave_01(i)==1
       h01_cell(m,1:10)=valid_cell(i,1:end-1);
         m=m+1;
   elseif llave_02(i)==1
       h02_cell(n,1:10)=valid_cell(i,1:end-1);
       n=n+1;
   end      
end

clearvars m n i h01 h02;

%% 5.d

calif01_mat=str2double(h01_cell(:,2:10));
calif02_mat=str2double(h02_cell(:,2:10));

calif01_mat(isnan(calif01_mat)==1)=0;
calif02_mat(isnan(calif02_mat)==1)=0;

for i=1:length(calif01_mat)
labmin01_v(i,1)=min(calif01_mat(i,1:5));
end

for i=1:length(calif02_mat)
labmin02_v(i,1)=min(calif02_mat(i,1:5));
end

labs_01=calif01_mat(:,1)+calif01_mat(:,2)+calif01_mat(:,3)+calif01_mat(:,4)+calif01_mat(:,5);
p_tec01=calif01_mat(:,6)+calif01_mat(:,7);
final01_v=(((labs_01-labmin01_v)/4)*30+p_tec01.*20/2+calif01_mat(:,8).*25+calif01_mat(:,9).*25);
final01_v=final01_v/100;

labs_02=calif02_mat(:,1)+calif02_mat(:,2)+calif02_mat(:,3)+calif02_mat(:,4)+calif02_mat(:,5);
p_tec02=calif02_mat(:,6)+calif02_mat(:,7);
final02_v=(((labs_02-labmin02_v)/4)*30+p_tec02.*20/2+calif02_mat(:,8).*25+calif02_mat(:,9).*25);
final02_v=final02_v/100;

clearvars labs_01 labs_02 p_tec01 p_tec02 i;

%% 5.e

disp(['Nota promedio del horario h01: ', num2str(mean(final01_v,1)),' Porcentaje de aprobados: ',num2str(sum((final01_v(:)>=11))/32*100),'%']);
disp(['Nota promedio del horario h02: ', num2str(mean(final02_v,1)),' Porcentaje de aprobados: ',num2str(sum((final02_v(:)>=11))/32*100),'%']);

%% 5.f

final_total_v=[final01_v(:,1);final02_v(:,1)];

s_nota=(final_total_v-mean(final_total_v))./std(final_total_v);

for i=1:length(final_total_v)
    if s_nota(i,1)>=2
        letra_v(i,1)="A+";
    elseif s_nota(i,1)>=1 & s_nota(i,1)<2
        letra_v(i,1)="A";
    elseif s_nota(i,1)>=0 & s_nota(i,1)<1
        letra_v(i,1)="B";
    elseif s_nota(i,1)>=-1 & s_nota (i,1)<0
        letra_v(i,1)="C";
    elseif s_nota(i,1)>=-2 & s_nota (i,1)<-1
         letra_v(i,1)="D";
    elseif s_nota(i,1)<-2
         letra_v(i,1)="F";
    end
end

clearvars s_nota final_total_v i;

%% 5.g

A_1=sum(letra_v(:)=="A+");
A_0=sum(letra_v(:)=="A");
B=sum(letra_v(:)=="B");
C=sum(letra_v(:)=="C");
D=sum(letra_v(:)=="D");
F=sum(letra_v(:)=="F");

disp (["Calificaciones A+:",num2str(A_1)]);
disp (["Calificaciones A:",num2str(A_0)]);
disp (["Calificaciones B:",num2str(B)]);
disp (["Calificaciones C:",num2str(C)]);
disp (["Calificaciones D:",num2str(D)]);
disp (["Calificaciones F:",num2str(F)]);

clearvars A_1 A_0 B C D F;







