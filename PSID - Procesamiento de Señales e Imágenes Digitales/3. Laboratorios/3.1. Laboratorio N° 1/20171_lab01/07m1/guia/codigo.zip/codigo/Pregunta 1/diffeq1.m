function [ y ] = diffeq1( x )
%DIFFEQ1 Implementar la ecuación diferencial y[n] = x[n] + 2.5 y[n-1] -
%y[n-2], suponiendo un sistema causal
% x: señal de entrada de longitud N, definida en el intervalo n = 0:N-1
% y: señal de salida de longitud N, definida en el intervalo n = 0:N-1
       
end

