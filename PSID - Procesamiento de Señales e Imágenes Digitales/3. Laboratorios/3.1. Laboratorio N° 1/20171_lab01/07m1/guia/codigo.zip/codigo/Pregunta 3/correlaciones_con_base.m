function [ correlaciones ] = correlaciones_con_base( senal_entrada, senales_base )
%CORRELACIONES_CON_BASE 
%   senal_entrada: señal nueva que va a ser clasificada
%   senales_base: matriz donde cada columna es una de las señales base para
%   cada una de las vocales
%   correlaciones: matriz de salida donde cada columna es la correlación
%   cruzada de senal_entrada con cada una de las columnas de senales_base
    
end

