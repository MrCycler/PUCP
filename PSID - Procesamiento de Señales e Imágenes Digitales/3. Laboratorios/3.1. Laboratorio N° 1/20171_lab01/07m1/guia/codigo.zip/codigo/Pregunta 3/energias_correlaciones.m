function [ energias ] = energias_correlaciones( correlaciones )
%ENERGIAS_CORRELACIONES Calcula la energia de las columnas de la matriz
% correlaciones: matriz de entrada donde cada columna es una de las
%                correlaciones cruzadas halladas en el paso anterior
%      energias: vector con las energías de cada columna de la matriz
%                correlaciones

end

