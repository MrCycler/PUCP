function [ y ] = diffeq2( x, K )
%DIFFEQ1 Implementar la ecuación en diferencias de la segunda pregunta de la
%guía, suponiendo un sistema causal
% x: señal de entrada de longitud N, definida en el intervalo n = 0:N-1
% K: parámetro de realimentación mayor a cero
% y: señal de salida de longitud N, definida en el intervalo n = 0:N-1
       
    
end

