% IEE239: Guía de Laboratorio
% Primera sesion de laboratorio, Semestre 2017-1
%% Pregunta 3
% NO MODIFICAR NADA DEL PRESENTE CÓDIGO

clear; close all; clc;

%% Leer señales

load('senales_base');
load('senales_prueba','senales_prueba')

num_tests = length(senales_prueba);

for ii=1:num_tests
    test_signal = senales_prueba{ii};
    %% Correlaciones
    [ correlaciones ] = correlaciones_con_base( test_signal, senales_base );
    %% Energías
    [ energias(ii,:) ] = energias_correlaciones( correlaciones );
end

[ performance, comparacion] = clasificacion( energias );

disp(['La clasificación del sistema es de ' num2str(performance) '%'])
errores = sum(comparacion==0);
if errores>0
disp(['Hubo un error en ' num2str(errores) ' señales'])
end
