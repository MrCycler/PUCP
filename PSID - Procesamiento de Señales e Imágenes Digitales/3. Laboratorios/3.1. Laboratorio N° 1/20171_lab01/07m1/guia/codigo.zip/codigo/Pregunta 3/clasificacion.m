function [ accuracy, compara] = clasificacion( energias )
%CLASIFICACION Función que realiza la clasificación y calcula un valor de
%precisión
% NO MODIFICAR NADA DEL PRESENTE CÓDIGO

    load('senales_prueba','etiquetas')
    
    accuracy=0;
    
    for zz=1:size(energias,1)
        [~,pos] = max(energias(zz,:));
        compara(zz)=(pos==etiquetas(zz));
        accuracy = accuracy + (pos==etiquetas(zz));
    end
    
    accuracy = 100*accuracy/size(energias,1);

end

