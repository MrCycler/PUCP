function [ y ] = filtroH( x, polos )
%FILTROH Implementar el filtro H descrito en la aplicación asumiendo
%causalidad
% x: señal de entrada de longitud N definida en el intervalo 0:N-1
% polos: vector que contiene los 6 polos del sistema
% y: señal de salida de longitud N definida en el intervalo 0:N-1

end

