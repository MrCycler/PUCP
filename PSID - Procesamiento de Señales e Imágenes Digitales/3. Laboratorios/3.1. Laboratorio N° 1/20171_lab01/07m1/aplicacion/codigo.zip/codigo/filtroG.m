function [ y ] = filtroG( x)
%FILTROG Implementar el filtro dado por G(z) = 1 - z^{-1} asumiendo
%causalidad
% x: señal de entrada de longitud N definida en el intervalo 0:N-1
% y: señal de salida de longitud N definida en el intervalo 0:N-1

end

