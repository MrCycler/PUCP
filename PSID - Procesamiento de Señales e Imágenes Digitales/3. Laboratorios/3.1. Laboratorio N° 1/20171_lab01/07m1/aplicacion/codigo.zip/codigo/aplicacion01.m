% IEE239: Aplicación
% Primera sesion de laboratorio, Semestre 2017-1
% NO MODIFICAR NADA DEL PRESENTE CÓDIGO

clc;
clear;
close all;

vocales = {'a','i','e'};
tabla_freqs = [520 1190 2390; % a
               270 2290 3010; % i
               530 1840 2480]; % e
r = 0.95;   % amplitud de los polos 
fs = 8000; % frecuencia de muestreo
f0 = 70; % frecuencia del tren de pulsos
T = floor(fs/f0); % periodo del tren de pulsos (en muestras)
N = 5000; % longitud de tren de pulsos


for k=1:length(vocales)
   disp (['generando ' vocales(k)])

    polos = generar_polos(tabla_freqs(k,1),tabla_freqs(k,2),tabla_freqs(k,3),fs,r);
    x = generar_pulso( N, T);
    y = filtroH(x,polos);
    z = filtroG(y);
    z = z/max(abs(z));

    disp('Presione cualquier tecla para escuchar la vocal sintetizada')
    pause
    sound(z,fs)
end