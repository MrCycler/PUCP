function [ polos ] = generar_polos( f1,f2,f3,fs,r )
%GENERAR_POLOS Función que genera los polos del filtro H tal como es
%decrito en la aplicación
% f1,f2,f3: frecuencias específicas de la vocal
% fs: frecuencia de muestreo
% r: amplitud de los polos
% polos: vector de seis elementos que contiene los polos generados

end

