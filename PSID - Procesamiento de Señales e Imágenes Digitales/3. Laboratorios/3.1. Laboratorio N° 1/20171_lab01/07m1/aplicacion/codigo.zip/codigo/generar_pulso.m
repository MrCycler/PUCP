function [ x ] = generar_pulso( N, T )
%GENERAR_PULSO genera un tren de pulsos
% N: número de muestras del tren de pulsos
% T: periodo (en muestras) del tren de pulsos
% x: tren de pulsos definido en el itnervalo n = 0:N-1

end

