%% Autor: Pablo D�az
%% Curso: PSID
%% Codigo: 20145789
%% Ciclo: 08M2
%% Guia 2

%% Pregunta 1
%% 1.a 
% Se tiene omega:
% primer termino 2*pi*10*t
% segundo termino 2*pi*40*t
% y se sabe que la Fminima=2*Fmax_del_sist
% Entonces la Fmin=80Hz.
%% 1.b
% Se va a muestrear la se�al en dos frecuencias diferentes
N=120;
n=0:N-1; % numero de muestras
Tiempo=1.75;

% inciso i)

T1=1.75/120;
x_1=10*cos(2*pi*10*n*T1)+5*cos(2*pi*40*n*T1).^2; % La se�al discreta

Y_1=fft(x_1); % transformada de fourier
Y_shift1=fftshift(Y_1); % centramos el espectro en el rango fundamental
Y_mag1=abs(Y_shift1); % Vemos la magnitud
fase_1=unwrap(angle(Y_1)); % Vemos la fase de trans.
w_n1=2*pi*(0:N-1)/N; % muestr de frecencia en el r. fund.
w_n1=unwrap(angle(Y_1)); % Fase de trans. F

% inciso ii)

Fs=200;%Hz
Ts=1/200;% Periodo de muestreo
x_2=10*cos(2*pi*10*n*Ts)+5*cos(2*pi*40*n*Ts).^2; % La se�al discreta
Y_2=fft(x_2); %transformadad de Fourier
Y_shift2=fftshift(Y_2); % Centramos el espectro en el rango fundamental
Y_mag2=abs(Y_shift2); %Vemos la magnitud
Fase=unwrap(angle(Y_2)); % fase de la transf.
w_n2=2*pi*(0:N-1)/N;% muestr. de frecuencia en el rang. fund.
w_n2=unwrap(angle(Y_2)); % fase de trans. de fourier

figure
% Graficos de x1 y x2
subplot(3,2,1),plot(n*T1,x_1,'- g'),xlabel('N=120'),ylabel(''),title('Se�al discreta X_1 [n]'), grid on, axis tight;
subplot(3,2,2),plot(n*Ts,x_2,'- r'),xlabel('Ts=1/200 '),ylabel(''),title('Se�al discreta X_2 [n]'), grid on, axis tight;
% Especttro de magnitud
subplot(3,2,3),stem(w_n1,Y_mag1,'-o b'),xlabel('N=120'),ylabel('X_e^(j*omega) 1'), grid on, axis tight;
subplot(3,2,4),stem(w_n2,Y_mag2,'-o b'),xlabel('n*Ts'),ylabel('X_e^(j*omega) 2'), grid on, axis tight;
% Espectro de fase
subplot(3,2,5),stem(w_n1,fase_1,'-o b'),xlabel('Frecuencia 1'),ylabel('angulo 1'), grid on, axis tight;
subplot(3,2,6),stem(w_n2,Fase,'-o b'),xlabel('Frecuencia 2'),ylabel('angulo 2'), grid on, axis tight;

% �Existe alguna distorsi�on en las se�nales generadas? Explicar
% claramente su respuesta.

% S� existe una distorsion ya que en el
% dominio de frecuencia dentro del rango fund.
% no se logra captar que existen
% informacion de la se�al que se eliminan
% por tomar un rango de datos que no cumplen
% con ser multiplo entero(+) de la frec. de la se�al
% o del numero de muestras
% Entonces existe una fuga espectral

%% 1.c

% Calc. el minimo numero de muestras
% faltantes para completar un numero
% de periodos de la se�al x_2 [n]

% La frecuencia ideal ser�a de 240 Hz

N=240;
n=0:N-1; % numero de muestras
Tiempo=1.75;
% inciso i)
T3=1.75/120;
x_3=10*cos(2*pi*10*n*T3)+5*cos(2*pi*40*n*T3).^2; % La se�al discreta

Y_3=fft(x_3); % transformada de fourier
Y_shift3=fftshift(Y_3); % centramos el espectro en el rango fundamental
Y_mag3=abs(Y_shift3); % Vemos la magnitud
fase_3=unwrap(angle(Y_3)); % Vemos la fase de trans.
w_n3=2*pi*(0:N-1)/N; % muestr de frecencia en el r. fund.
w_n3=unwrap(angle(Y_3)); % Fase de trans. F

figure
stem(w_n3,Y_mag3,'- r'),title('x_3 [n] f=240Hz Espectro de magnitud');
% Vemos claramente que ahora s� se cumplen
% las leyes para un correcto muestreo.

%% 1.d
% Analizando nuevamente la onda

Fs=200; % Frecuencia de muestreo
Ts=1/200; % Periodo de muestreo

F_m=2*40;
T_m=1/F_m;
n=0:500;

x_c=10*cos(2*pi*40*n*Ts)+5*cos(2*pi*40*n*Ts).^2; % La se�al discreta

x_am=x_c*cos(2*pi*F_m*n*T_m);


%% Pregunta 2
%% 2.a
% Cargamos los archivos
clc;
clear all;
close all;

load('r.mat');

Fs=4000;
Ts=1/Fs; % Periodo de muestreo
L=length(r);
N_1=L+128; % DFT
N_2=L+1024; %DFT

Y_nuevo=fftshift(r); % centramos en el ran. fundamental
Y_nuevo_mag=abs(Y_nuevo); % Calculamos la magnitud
Y_nuevo_fase=unwrap(phase(Y_nuevo)); 


Y_nuevo_mag2=abs(fftshift(fft(r,128)));
Y_nuevo_mag3=abs(fftshift(fft(r,1024)));

figure
subplot(3,1,1),stem(0:L-1,Y_nuevo_mag),title('Espectro de magnitud R'),xlabel('Frec'),ylabel('|X_e^(j*omega)|'), grid on, axis tight;
subplot(3,1,2),stem(0:N_1-1,Y_nuevo_mag_2),title('Espectro de magnitud R N=L+128'),xlabel('Frec'),ylabel('|X_e^(j*omega)|'), grid on, axis tight;
subplot(3,1,3),stem(0:N_2-1,Y_nuevo_mag_3),title('Espectro de magnitud R N=L+1024'),xlabel('Frec'),ylabel('|X_e^(j*omega)|'), grid on, axis tight;



%% 2.b

load('g.mat');

Tiempo=2;
Fs=4000;
Ts=1/Fs; % Periodo de muestreo
n=0:(0.5/Ts-1); % numero de muestras
N=Tiempo/Ts; % Calculamos N
L=length(g);

Y_g=fft(g);
Y_shift_g=fftshift(Y_g); % centramos en el rango fund
Y_mag_g=abs(Y_shift_g);% magnitud
Fase_g=unwrap(angle(Y_g)); % fase de la trans
w_n_g=2*pi*(0:N-1)/N; % muestra de frec en el rang. fund
w_n_g=unwrap(angle(Y_g)); % fase de transf. fourier

%Y_nuevo=fftshift(g); % centramos en el ran. fundamental
%Y_nuevo_mag=abs(Y_nuevo); % Calculamos la magnitud
%Y_nuevo_fase=unwrap(phase(Y_nuevo)); 


% G1f=abs(fftshift(fft(g,1024))); % calculamos la magnitud
% w_g=2*pi*(0:((length(G1f)-1))/length(G1f));


figure
subplot(3,1,1),stem(0:length(g)-1,g),title('Datos de g.mat'),xlabel('L'),ylabel('g'),grid on, axis tight;
subplot(3,1,2),stem(w_n_g,Y_mag_g),title('Magnitud'),xlabel('Frec'),ylabel('Magnitud'), grid on, axis tight;
subplot(3,1,3),stem(w_n_g,Fase_g),title('Fase'),xlabel('Frec'),ylabel('Angulo'), grid on, axis tight;

% Indicar el n�mero de tonos que conforma la se�al
% y sus recuencias angulares y sus frec. fund

% Tonos= 6
% frec ang= 
% frec fund=

%% 2.c

%% 2.d

%% Pregunta 3

% D1 desconocido
% D2 desconocido

% I1=D1;
% I2=D2;


%% 3.a

n=0:2000-1; 

% Vemos la se�al discreta
x_n=10*sin(2*pi*75.*n/1000)+10/2*sin(2*pi*75*2.*n/1000);

resp_1=bloque1(x_n);
N1=length(resp_1);


Y_r_1=fft(resp_1); % transformada de fourier
Y_shift_r1=fftshift(Y_r_1); % centramos el espectro en el rango fundamental
Y_mag_r_1=abs(Y_shift_r1); % Vemos la magnitud
fase_r_1=unwrap(angle(Y_r_1)); % Vemos la fase de trans.
w_r_1=2*pi*(0:N1-1)/N1; % muestr de frecencia en el r. fund.
w_r_1=unwrap(angle(Y_r_1)); % Fase de trans. F


resp_2=bloque2(x_n);
N2=length(resp_2);

Y_r_2=fft(resp_2); % transformada de fourier
Y_shift_r2=fftshift(Y_r_2); % centramos el espectro en el rango fundamental
Y_mag_r_2=abs(Y_shift_r2); % Vemos la magnitud
fase_r_2=unwrap(angle(Y_r_2)); % Vemos la fase de trans.
w_r_2=2*pi*(0:N2-2)/N2; % muestr de frecencia en el r. fund.
w_r_2=unwrap(angle(Y_r_2)); % Fase de trans. F



figure
% Graficos de x1 y x2
subplot(3,2,1),plot(0:N1-1,resp_1,'- g'),xlabel('N=120'),ylabel(''),title('Respuesta a bloque 1'), grid on, axis tight;
subplot(3,2,2),plot(0:N2-1,resp_2,'- r'),xlabel('Ts=1/200 '),ylabel(''),title('Respuesta a bloque 2'), grid on, axis tight;
% Especttro de magnitud
subplot(3,2,3),stem(w_r_1,Y_mag_r_1,'-o b'),xlabel('/omega'),ylabel('|X_e^(j*omega) 1|'), grid on, axis tight;
subplot(3,2,4),stem(w_r_2,Y_mag_r_2,'-o b'),xlabel('/omega'),ylabel('|X_e^(j*omega) 2|'), grid on, axis tight;
% Espectro de fase
subplot(3,2,5),stem(w_r_1,fase_r_1,'-o b'),xlabel('/omega'),ylabel('angulo 1'), grid on, axis tight;
subplot(3,2,6),stem(w_r_2,fase_r_2,'-o b'),xlabel('/omega'),ylabel('angulo 2'), grid on, axis tight;


% Para el bloque 1: Se ha aplicado un sobremuestreo
% ya que en la imagen tanto de fase como la de frecuencia
% se presenta una frecuencia de corte.
% D1=5;

% Para el bloque 2: Se ha aplicado un Diezmado
% ya que aparecen las repeticiones dentro del rango
% fundamental en la gr�fica de angulos
% por lo que ser�a un D=3 ya que se tiene
% una frec de corte
% D2=8;

%% 3.b

load('signal_preg3.mat'); % Se cargan los datos
load ('filtro.mat');
% Algunos datos necesarios
M=100;
n=0:M-1; % numero de muestras

% Datos
D1=3;
D2=8;

D3=10;
D4=5;

I1=D1;
I2=D2;
I3=D3;
I4=D4;

% Respuesta del filtro
hlp_1=1/D1*sinc(1/D1*(n-M/2));
hlp_2=1/D2*sinc(1/D2*(n-M/2));
hlp_3=1/D3*sinc(1/D3*(n-M/2));
hlp_4=1/D4*sinc(1/D4*(n-M/2));

% Bloques que faltan
x_1=bloque1(x);
x_2=bloque2(x);
x_3=downsample(conv(x,hlp_1),D3,0);
x_4=downsample(x,D4,0);



% Convolucionar el sistema
a_1=conv(x_1,h,'same');
a_2=conv(x_2,h,'same');
a_3=conv(x_3,h,'same');
a_4=conv(x_4,h,'same');

% Ahora viene la interpolacion

subida_1=zeros(2*length(a_1)-1,1);
subida_1(1:I1:end)=a_1;
subida_1=conv(subida_1,hlp_1,'same');

subida_2=zeros(2*length(a_2)-1,1);
subida_2(1:I2:end)=a_2;
subida_2=conv(subida_2,hlp_2,'same');

subida_3=zeros(2*length(a_3)-1,1);
subida_3(1:I3:end)=a_3;
subida_3=conv(subida_3,hlp_3,'same');

subida_4=zeros(2*length(a_4)-1,1);
subida_4(1:I4:end)=a_4;
subida_4=conv(subida_4,hlp_4,'same');

% Hacemos convergencia

y_1=conv(subida_1,hlp_1);
y_2=conv(subida_2,hlp_2);
y_3=conv(subida_3,hlp_3);
y_4=conv(subida_4,hlp_4);










%% 3.c

%


%






