%% Autor: Pablo D�az
%% Curso: PSID
%% Codigo: 20145789
%% Ciclo: 08M2
%% Aplicacion 2
clc
clear all;
close all;
%% Problema 1
%% 1.a

m=2;

Tiempo=6;
F_c=2000; % Frecuencia de entrada
T_c=1/F_c; % Periodo de entrada
B=500; % Ancho de banda

Fs_min=(2*F_c+B)/(m+1);
Fs_max=(2*F_c-B)/(m+1);
Fs=(Fs_min+Fs_max)/2;
Ts=1/Fs;
n=0:(6/Ts-1); % numero de muestras
N=Tiempo/Ts; % Calculamos N
t=n*Ts; % para la se�al discreta vamos a usar n*Ts

% Secuencia discreta
x_c_1=5*cos(2*pi*(F_c-B/2)*t)+10*cos(2*pi*F_c*t)+5*cos(2*pi*(F_c+B/2)*t);

plot_DFT(x_c_1,F_c,Fs);

%%
m=3;

Fs_min=(2*F_c+B)/(m+1);
Fs_max=(2*F_c-B)/(m+1);
Fs=(Fs_min+Fs_max)/2;
Ts=1/Fs;
n=0:(6/Ts-1); % numero de muestras
N=Tiempo/Ts; % Calculamos N
t=n*Ts; % para la se�al discreta vamos a usar n*Ts

x_c_2=5*cos(2*pi*(F_c-B/2)*t)+10*cos(2*pi*F_c*t)+5*cos(2*pi*(F_c+B/2)*t);

plot_DFT(x_c_2,F_c,Fs);


%% 1.b

M=100; % coef. pasabao
w_c=pi/2;
n=0:M-1; % numero de muestras
h_n=w_c/pi*sinc(w_c/pi*(n-M/2));
Ts=pi;
plot_DFT(n,w_c,Ts);


%% 1.c

Nx=M;

x_original=x_c_1;
X_new=fft(x_original); % Hacemos trans. de fourier
X_shift=fftshift(X_new);
X_mag=abs(X_shift);
fase_x=unwrap(angle(X_new));
w_x=2*pi*(0:Nx-1)/Nx;
w_x=unwrap(angle(X_new));

z_mag=zeros(1,100);
z_mag=X_mag(1:80:end);

H_new=fft(h_n);
H_shift=fftshift(H_new);
H_mag=abs(H_shift);
fase_h=unwrap(angle(H_new));
w_h=2*pi*(0:Nx-1)/Nx;
w_h=unwrap(angle(H_new));

y_n=z_mag.*H_mag;

stem(w_h,y_n);

plot_DFT(y_n,w_h,Ts);

%% 1.d

I=3; % Interpolacion con un factor de 3
% y_n es nuestra salida del inciso anterior
subida=zeros(2*length(y_n)-1,1);
subida(1:I:end)=y_n;
subida=conv(subida,h_n,'same'); % convolucion del sistema

%% 1.e
w =0.75*pi;
% Primer punto
posi=zeros(N,1);
nega=zeros(N,1);

posi=y_n(y_n>0);
nega=y_n(y_n<0);

% segundo punto
K=0.75*N/(2*pi);

% tercer punto

