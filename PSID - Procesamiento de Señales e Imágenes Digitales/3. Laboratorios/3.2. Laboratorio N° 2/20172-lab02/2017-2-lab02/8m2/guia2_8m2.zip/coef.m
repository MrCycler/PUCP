function [ Ck ] = coef(k)
if (k == 0) || (mod(k,2)==0)
    Ck=0;
else
    Ck=(cos(2*pi*k/3)-cos(pi*k/3))/(1j*k*pi);
end
end
    